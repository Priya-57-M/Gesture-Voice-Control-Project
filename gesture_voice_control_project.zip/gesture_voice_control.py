import cv2
import mediapipe as mp
import pyautogui
import speech_recognition as sr
import time
import numpy as np
import webbrowser
import os

# Initialize Mediapipe Hand Tracking
mp_hands = mp.solutions.hands
mp_drawing = mp.solutions.drawing_utils
hands = mp_hands.Hands(min_detection_confidence=0.7, min_tracking_confidence=0.7)

# Initialize Voice Recognition
recognizer = sr.Recognizer()

def voice_command():
    with sr.Microphone() as source:
        print("Proton is listening for your command...")
        recognizer.adjust_for_ambient_noise(source)
        try:
            audio = recognizer.listen(source, timeout=15)  # Increased timeout to 15 seconds
            command = recognizer.recognize_google(audio).lower()
            print("You said to Proton:", command)
            return command
        except sr.UnknownValueError:
            print("Proton didn't catch that.")
            return ""
        except sr.RequestError:
            print("Proton couldn't reach the speech service.")
            return ""
        except Exception as e:
            print(f"Error in listening: {e}")
            return ""

def open_chrome_with_query(command):
    print("Opening Chrome...")  # Debugging line
    query = command.replace("open youtube", "").strip().lower()  # Handling 'open youtube' specifically
    print("Search query:", query)  # Debugging line

    # Check for YouTube
    if "open youtube" in query:
        search = query.replace("open youtube", "").strip()
        if search:
            url = f"https://www.youtube.com/results?search_query={search.replace(' ', '+')}"
        else:
            url = "https://www.youtube.com"
    
    elif "wikipedia" in query:
        search = query.replace("wikipedia", "").strip()
        if search:
            url = f"https://en.wikipedia.org/wiki/{search.replace(' ', '_')}"
        else:
            url = "https://www.wikipedia.org"

    elif "google" in query:
        search = query.replace("google", "").strip()
        if search:
            url = f"https://www.google.com/search?q={search.replace(' ', '+')}"
        else:
            url = "https://www.google.com"
    
    else:
        url = f"https://www.google.com/search?q={query.replace(' ', '+')}" if query else "https://www.google.com"

    try:
        chrome_path = "C:/Program Files/Google/Chrome/Application/chrome.exe %s"  # Update if needed
        webbrowser.get(chrome_path).open(url)
        print(f"Opening URL: {url}")  # Debugging line
    except Exception as e:
        print(f"Error opening Chrome: {e}")
        webbrowser.open(url)

def handle_special_voice_commands(command):
    print("Handling command:", command)  # Debugging line
    if "play" in command and "song" in command:
        search = command.replace("play", "").replace("song", "").strip()
        url = f"https://www.youtube.com/results?search_query={search.replace(' ', '+')}"
        webbrowser.open(url)
        print(f"Proton is playing {search} songs on YouTube...")

    elif "zoom in" in command:
        pyautogui.hotkey('ctrl', '+')
        print("Proton zoomed in.")

    elif "zoom out" in command:
        pyautogui.hotkey('ctrl', '-')
        print("Proton zoomed out.")

    elif "open calculator" in command:
        os.system("calc")
        print("Proton opened Calculator.")

    elif "open file explorer" in command:
        os.system("explorer")
        print("Proton opened File Explorer.")

    elif "open youtube" in command:  # Updated here to handle "open youtube"
        open_chrome_with_query(command)

    elif "what's the time" in command:
        print("Proton says the time is:", get_time())

    elif "what's the weather" in command:
        city = command.replace("what's the weather", "").strip()
        print("Proton says:", get_weather(city))

    elif "tell me a joke" in command:
        print("Proton says:", chatgpt_interaction("Tell me a joke."))

def process_gesture(landmarks, width, height, prev_tap):
    index_finger = landmarks.landmark[8]
    middle_finger = landmarks.landmark[12]
    thumb_finger = landmarks.landmark[4]
    
    ix, iy = int(index_finger.x * width), int(index_finger.y * height)
    mx, my = int(middle_finger.x * width), int(middle_finger.y * height)
    tx, ty = int(thumb_finger.x * width), int(thumb_finger.y * height)
    
    pyautogui.moveTo(ix, iy, duration=0.1)

    if abs(iy - my) < 20:
        if time.time() - prev_tap > 0.5:
            pyautogui.doubleClick()
            print("Double Click")
            return time.time()
    elif abs(iy - my) > 50:
        pyautogui.mouseDown()
        pyautogui.moveTo(ix, iy, duration=0.1)
        pyautogui.mouseUp()
        print("Drag and Drop")
    elif abs(iy - ty) < 20:
        if ix < width // 2:
            pyautogui.press('volumeup')
            print("Increasing Volume")
        else:
            pyautogui.press('volumedown')
            print("Decreasing Volume")
    elif abs(ix - mx) < 20:
        pyautogui.click()
        print("Left Click")
    elif abs(mx - ix) < 20 and abs(mx - my) < 20:
        pyautogui.rightClick()
        print("Right Click")
    
    return prev_tap

# Main loop
cap = cv2.VideoCapture(0)
adaptive_camera = True
prev_tap = time.time()

while True:
    if adaptive_camera:
        command = voice_command()
        if "activate camera" in command:
            adaptive_camera = False
            print("Proton activated the camera.")
        elif "deactivate camera" in command:
            adaptive_camera = True
            print("Proton deactivated the camera.")
        elif "shutdown" in command:
            print("Proton is shutting down.")
            break
        else:
            handle_special_voice_commands(command)
    
    if not adaptive_camera:
        ret, frame = cap.read()
        if not ret:
            continue
        
        frame = cv2.flip(frame, 1)
        rgb_frame = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
        results = hands.process(rgb_frame)
        
        if results.multi_hand_landmarks:
            for hand_landmarks in results.multi_hand_landmarks:
                prev_tap = process_gesture(hand_landmarks, frame.shape[1], frame.shape[0], prev_tap)
                mp_drawing.draw_landmarks(frame, hand_landmarks, mp_hands.HAND_CONNECTIONS)
        
        cv2.imshow("Proton - Virtual Mouse", frame)
        
        if cv2.waitKey(1) & 0xFF == ord('q'):
            print("Exiting Proton...")
            break

cap.release()
cv2.destroyAllWindows()
